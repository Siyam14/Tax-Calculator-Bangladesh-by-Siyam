package com.taxcalculatorbangladesh;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etIncome,etAge,etInvestAmount;
    RadioGroup genderGroup,occupationGroup,investGroup,etDistrict;
    Button btnSubmit;
    TextView tvdisplay1, tvdisplay2,tvdisplay3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        etIncome = findViewById(R.id.etIncome);
        etAge = findViewById(R.id.etAge);
        etInvestAmount = findViewById(R.id.etInvestAmount);
        etDistrict = findViewById(R.id.etDistrict);
        genderGroup = findViewById(R.id.genderGroup);
        occupationGroup = findViewById(R.id.occupationGroup);
        investGroup = findViewById(R.id.investGroup);
        btnSubmit = findViewById(R.id.btnSubmit);
        tvdisplay1 = findViewById(R.id.tvdisplay1);
        tvdisplay2 = findViewById(R.id.tvdisplay2);
        tvdisplay3 = findViewById(R.id.tvdisplay3);


        investGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rbInvestYes) {
                    etInvestAmount.setVisibility(View.VISIBLE);
                } else {
                    etInvestAmount.setVisibility(View.GONE);
                }
            }
        });


        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String incomeText = etIncome.getText().toString().trim();
                String ageText = etAge.getText().toString().trim();
                String investText = etInvestAmount.getText().toString().trim();

                if (incomeText.isEmpty()) {
                    etIncome.setError("আয় লিখুন");
                    return;
                }

                if (ageText.isEmpty()) {
                    etAge.setError("বয়স লিখুন");
                    return;
                }

// radio button validation
                int selectedGenderId = genderGroup.getCheckedRadioButtonId();
                int selectedOccupationId = occupationGroup.getCheckedRadioButtonId();
                int selectedInvestId = investGroup.getCheckedRadioButtonId();
                int selectedDistrictId = etDistrict.getCheckedRadioButtonId();

                if (selectedGenderId == -1 || selectedOccupationId == -1 || selectedInvestId == -1 || selectedDistrictId == -1) {
                    Toast.makeText(MainActivity.this, "সব ফিল্ড সিলেক্ট করুন", Toast.LENGTH_SHORT).show();
                    return;
                }


                if (selectedInvestId == R.id.rbInvestYes && investText.isEmpty()) {
                    etInvestAmount.setError("বিনিয়োগের পরিমাণ লিখুন");
                    return;
                }


                float Income = Float.parseFloat(incomeText);
                float age = Float.parseFloat(ageText);
                float investment = 0;
                if (!investText.isEmpty()) {
                    investment = Float.parseFloat(investText);
                }


















                double texfree = 350000;
                if(selectedGenderId == R.id.rbFemale) texfree = 400000;
                if(selectedGenderId == R.id.rbOther) texfree = 475000;
                if(R.id.etAge >65) texfree = 400000;

                double texablebalance = Income - texfree;
                if (texablebalance <= 0) texablebalance=0;

                //district factor

                double districtfactor = 1.00;
                if (selectedDistrictId == R.id.rb2) districtfactor = 0.98;
                if (selectedDistrictId == R.id.rb3) districtfactor = 1.02;
                if (selectedDistrictId == R.id.rbOther3) districtfactor = 1.00;

                //professionfactor

                double professionfactor = 1.00;
                if (selectedOccupationId == R.id.rbJob) professionfactor = 0.90;
                if (selectedOccupationId == R.id.rbFreelance) professionfactor = 1.10;

                //Inverstment factor


                investment = 0;
                if (!investText.isEmpty()) {
                    investment = Float.parseFloat(investText);
                }


                double investmentfactor = 1.00;
                if (selectedInvestId == R.id.rbInvestYes)  {


                    if (investment <= 10000 ) investmentfactor = 1.00;
                    else if (investment <=20000) investmentfactor = 0.95;
                    else if (investment <=30000) investmentfactor = 0.90;
                    else if (investment >30000) investmentfactor = 0.85;

                }

                double totalfactor =  districtfactor*  professionfactor*  investmentfactor;

                double texableamount = texablebalance* totalfactor;

               double tex=0;

               if (texableamount <=100000 ) tex = texableamount*0.05;
               else if (texableamount <=500000) tex = 5000 + ((texableamount - 100000) * 0.10);
               else if (texableamount <=1000000 ) tex = 5000+40000 + ((texableamount - 500000) * 0.15);
               else if (texableamount <=1500000 ) tex = 5000+40000 +  75000+((texableamount - 1000000) * 0.20);
               else if (texableamount <=3500000 ) tex = 5000+40000 +  75000+100000 + ((texableamount - 1500000) * 0.25);
               else  {
                   tex = 5000+40000 +  75000+100000 + 500000+ ((texableamount - 3500000) * 0.30);


               }





               tvdisplay1.setText("আপনার করযোগ্য আয়ঃ " +texablebalance+  " টাকা।");
               tvdisplay2.setText("করযোগ্য আয় (ফ্যাক্টর অনুযায়ী): " + texableamount + " টাকা।");
               tvdisplay3.setText("আপনাকে " + tex + " টাকা কর দিতে হবে।");









            }
        });


    }
}